import CajaText from "./ui/CajaText";
import InputGroup from "./ui/InputGroup";
import MiBoton from "./ui/MiBoton";
import SelectMenu from "./ui/SelectMenu";

export default function App() {
  return (
    <>
      <h1 className="text-3xl font-bold text-red-500 underline">
      Hello world!
      </h1>
      <CajaText placeholder="password" required type="password" />
      <CajaText placeholder="email" required type="email" />
      <CajaText placeholder="nombres" type="text"/>
      <div className="flex flex-row">
        <MiBoton>Aceptar</MiBoton>  
        <MiBoton>Cancelar</MiBoton>  
        <MiBoton>Salir</MiBoton>  
      </div>
      <InputGroup />
      <SelectMenu />
    </>
    
  )
}

