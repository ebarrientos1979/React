import React from 'react'

export default function CajaText({...props}) {
    return (
        <input type="text" className="border border-gray-400 p-2 bg-yellow-100 rounded-lg" 
        {...props} />
    )
}