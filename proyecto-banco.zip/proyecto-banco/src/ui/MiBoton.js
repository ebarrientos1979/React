export default function MiBoton({children}) {
    return (
        <button
            padding="2"
            className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
            {children}
        </button>
    )
}